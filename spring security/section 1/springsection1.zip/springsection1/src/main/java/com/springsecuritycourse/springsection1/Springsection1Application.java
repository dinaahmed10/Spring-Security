package com.springsecuritycourse.springsection1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springsection1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springsection1Application.class, args);
	}

}
